Regional Municipalaity

Field		Description
Area-ID		Unique system Identifier
Area_name	      Reginal Municipality name
ObectID		Unique Object Identifier